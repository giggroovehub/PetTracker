-- Create database if not exists
CREATE DATABASE IF NOT EXISTS user_db;

-- Switch to user_db database
USE user_db;

-- Create history table
CREATE TABLE IF NOT EXISTS history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    lat DECIMAL(10, 6) NOT NULL,
    lng DECIMAL(10, 6) NOT NULL,
    name VARCHAR(255) NOT NULL,
    address VARCHAR(255) NOT NULL,
    timestamp DATETIME NOT NULL
);

-- Optionally, create an index on timestamp field for faster queries
CREATE INDEX idx_timestamp ON history(timestamp);
