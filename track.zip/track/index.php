<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/output.css">
    <link rel="stylesheet" href="./css/styles.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@200..700&display=swap" rel="stylesheet">
    <style>
        /* General styles */
        body {
            margin: 0;
            font-family: "Oswald", sans-serif;
            background: #f0f0f0; /* Fallback color */
            background: linear-gradient(to bottom, #f0f0f0, #dddddd); /* Gradient background */
            color: #333;
        }

        /* Header styles */
        .header {
            font-size: 5vw; /* Responsive font size */
            text-align: center;
            margin-top: 10vh; /* Adjust top margin for spacing */
            font-style: italic;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3); /* Adjusted text shadow */
        }

        /* Button styles */
        .login, .signup {
            display: block;
            background-color: black;
            color: white;
            position: absolute;
            left: 50%; /* Center horizontally */
            transform: translateX(-50%); /* Adjust for centering */
            margin: 10px; /* Add margin to create distance */
            border-radius: 30px;
            padding: 10px 30px; /* Responsive padding */
            font-size: 18px; /* Fixed font size */
            text-align: center;
            text-decoration: none; /* Remove default underline */
        }

        /* Specific adjustments for each button */
        .login {
            top: 30%; /* Adjust as needed */
        }

        .signup {
            top: 40%; /* Adjust as needed to create vertical distance */
        }

        @media (max-width: 768px) {
            /* Adjustments for medium screens */
            .header {
                font-size: 7vw; /* Larger font size */
            }
            .login, .signup {
                padding: 8px 25px; /* Adjusted padding */
            }
            .login {
                top: 25%; /* Adjust as needed for smaller screens */
            }
            .signup {
                top: 35%; /* Adjust as needed for smaller screens */
            }
        }

        @media (max-width: 480px) {
            /* Adjustments for small screens */
            .header {
                font-size: 9vw; /* Even larger font size */
            }
            .login, .signup {
                padding: 6px 20px; /* Smaller padding */
                font-size: 16px; /* Smaller font size */
            }
            .login {
                top: 20%; /* Adjust as needed for very small screens */
            }
            .signup {
                top: 30%; /* Adjust as needed for very small screens */
            }
        }

        /* Background image styles */
        .bg {
            width: 100%; /* Ensure image stretches across container */
            height: auto; /* Maintain aspect ratio */
            display: block; /* Remove extra space below image */
            position: absolute; /* Position the image */
            top: 0; /* Align to the top of the container */
            left: 0; /* Align to the left of the container */
            z-index: -1; /* Place behind other content */
            opacity: 0.8; /* Adjust image opacity if needed */
        }

        /* Footer styles */
        .footer {
            background-color: black;
            color: #fff;
            padding: 10px;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .footer a {
            color: #fff;
            text-decoration: none;
            padding: 0 10px;
        }

        .footer a:hover {
            text-decoration: underline;
        }
    </style>
    <title>Login</title>
</head>
<body>

<h1 class="header">PetTracker</h1>

<a href="./user/login.php" class="login">Log In</a>
<a href="./user/register.php" class="signup">Sign Up</a>

<img class="bg" src="./images/bg.jpg" alt="Background Image">

<footer class="footer">
    <p>&copy; 2024 Pet Tracking App. All rights reserved.</p>
</footer>

</body>
<script src="./javascript/sessionmessage.js"></script>
</html>
