<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Simple Notes</title>
    <link rel="stylesheet" href="./note/css/style.css">

    <style> 
   /* Global Styling */
         /* Global Styling */
         body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 30px auto;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            margin-top: 100px;

        }

    
        /* Card and Form Styling */
        .card {
            border: none;
            background-color: #f8f9fa;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-title {
            color: #343a40;
            font-size: 1.2em;
            margin-bottom: 15px;
        }

        .form-control {
    border: 1px solid #ced4da;
    border-radius: 5px;
    padding: 10px;
    font-size: 18px; /* Increased font size */
}

        /* Button Styling */
        .btn-primary {
            background-color: #082D0F;
            border: none;
            padding: 12px 30px;
            font-size: 1em;
            border-radius: 5px;
            color: #ffffff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-secondary {
            background-color: #082D0F;
            border: none;
            padding: 12px 30px;
            font-size: 1em;
            border-radius: 5px;
            color: #ffffff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-danger {
            background-color: #082D0F;
            border: none;
            padding: 12px 30px;
            font-size: 1em;
            border-radius: 5px;
            color: #ffffff;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .btn-primary:hover, .btn-secondary:hover, .btn-danger:hover {
            background-color: #17B890;
        }

        /* Text and Heading Styling */
        .text-center {
            text-align: center;
            margin-bottom: 20px;
        }

        h2 {
            color: #343a40;
            font-size: 2em;
            font-weight: bold;
        }

        hr {
            border-color: #ced4da;
            margin: 30px 0;
        }

        /* Notes List Styling */
        #notes .card {
            margin-bottom: 15px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }
    
        .pet, .dash, .histo {
            position: fixed;
            top: 10px;
            padding: 10px 20px;
            text-decoration: none;
            color: #ffffff;
           background-color: #082D0F;
            border: 1px solid #28a745;
            border-radius: 5px;
            transition: background-color 0.3s, border-color 0.3s, color 0.3s;
        }

        .pet {
            left: 10px;
        }

        .dash {
            left: 190px; /* Adjust as needed */
        }

        .histo {
            left: 390px; /* Adjust as needed */
        }

        .pet:hover, .dash:hover, .histo:hover {
            background-color: #17B890;
            border-color: #218838;
        }

        .pet:active, .dash:active, .histo:active {
            background-color: #1e7e34;
            border-color: #1e7e34;
        }
      

</style>
</head>

<body>

<a href="pet-registration.php" class="pet">Go to Register Pet</a>
    <a href="MainDashboard.php" class="dash">Return to Dashboard</a>
    <a href="history.php" class="histo">Go to History</a>
    
    <div class="container my-3">
        <h2 class="text-center">Notes</h2>
        <div class="card shadow-sm rounded-0">
            <div class="card-body">
                <h5 class="card-title">Create New Note</h5>
                <div class="form-group">
                    <input type="hidden" name="key" value="">
                    <textarea id="addTxt" class="form-control rounded-0" rows="3"></textarea>
                </div>
                <div class="text-center">
                    <button id="addBtn" class="btn btn-primary rounded-0">Add Note</button>
                    <button id="cancelBtn" class="btn btn-secondary rounded-0 border">Cancel</button>
                </div>
            </div>
        </div>
        <hr>
        <h2 class="text-center">Notes List</h2>
        <hr>
        <div id="notes" class="row container-fluid m-2">
        </div>
    </div>
    <!----------JAVASCRIPT--------->
    <script src="./note/js/jquery.min.js"></script>
    <script src="./note/js/popper.min.js"></script>
    <script src="./note/js/bootstrap.min.js"></script>
    <script src="./note/js/app.js"></script>
</body>

</html>
