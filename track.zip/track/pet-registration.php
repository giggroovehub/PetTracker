<?php
session_start();

// Database connection settings
$servername = "localhost";
$username = "root";
$password = ""; // Replace with your MySQL password if set
$dbname = "user_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize or get existing registered pets array from session
$registeredPets = isset($_SESSION["registeredPets"]) ? $_SESSION["registeredPets"] : [];

// Process registration form and delete request
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if delete request
    if (isset($_POST["deleteIndex"]) && is_numeric($_POST["deleteIndex"])) {
        $deleteIndex = $_POST["deleteIndex"];
        // Check if index exists in session array
        if (isset($registeredPets[$deleteIndex])) {
            // Get pet details
            $petToDelete = $registeredPets[$deleteIndex];
            $petName = $petToDelete['petName'];
            $petAge = $petToDelete['petAge'];
            $ownerName = $petToDelete['ownerName'];

            // Delete pet from database based on pet details
            $stmt = $conn->prepare("DELETE FROM pets WHERE petName = ? AND petAge = ? AND ownerName = ?");
            $stmt->bind_param("sis", $petName, $petAge, $ownerName);
            if ($stmt->execute()) {
                // Remove pet from session array
                unset($registeredPets[$deleteIndex]);
                // Reset array keys
                $registeredPets = array_values($registeredPets);
                // Save updated registered pets array back to session
                $_SESSION["registeredPets"] = $registeredPets;
                // Redirect to refresh page after deletion
                header("Location: " . $_SERVER["PHP_SELF"]);
                exit();
            } else {
                echo "Error deleting pet: " . $stmt->error;
            }
            $stmt->close();
        }
    } else {
        // Add new pet to registered pets array
        $newPet = [
            "petName" => $_POST["petName"],
            "petAge" => $_POST["petAge"],
            "ownerName" => $_POST["ownerName"]
        ];
        
        // Insert new pet into the database
        $petName = $_POST["petName"];
        $petAge = $_POST["petAge"];
        $ownerName = $_POST["ownerName"];

        $stmt = $conn->prepare("INSERT INTO pets (petName, petAge, ownerName) VALUES (?, ?, ?)");
        $stmt->bind_param("sis", $petName, $petAge, $ownerName);

        if ($stmt->execute()) {
            // Add new pet to session array
            $newPet['id'] = null; // Adjust as per your application logic
            $registeredPets[] = $newPet;

            // Save updated registered pets array back to session
            $_SESSION["registeredPets"] = $registeredPets;

            // Redirect to same page to refresh the list after successful insertion
            header("Location: " . $_SERVER["PHP_SELF"]);
            exit();
        } else {
            echo "Error inserting new pet: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Our Pets</title>
    <style>
         body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color: white;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid #ccc;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            font-size: 16px;
        }

        th {
            background-color: #f2f2f2;
        }

        form {
            display: inline; /* Keep forms inline for delete buttons */
        }

        .delete-btn {
            background-color: red;
            color: white;
            border: none;
            padding: 8px 12px;
            cursor: pointer;
            font-size: 14px;
        }

        h1,
        h2 {
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
            align-items: center; /* Center align items horizontally */
            max-width: 400px; /* Example of setting a maximum width for the form */
            margin: 0 auto; /* Center align form horizontally */
            padding: 20px;
            background-color: #f2f2f2; /* Light gray background for form */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); /* Shadow for form */
        }

        label,
        input {
            margin-bottom: 10px;
            padding: 12px;
            border-radius: 5px;
            font-size: 16px;
            border: 1px solid #ccc;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            padding: 15px 30px;
            background-color: #082D0F;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #17b890;
        }

        .pets-container {
            text-align: center;
            margin: 0 auto;
            max-width: 800px;
        }

        p {
            font-size: 16px;
        }

        .Back,
        .map {
            display: inline-block;
            padding: 10px 20px;
            margin: 10px;
            text-decoration: none;
            color: #ffffff;
            background-color: #082D0F;
            border: 1px solid green;
            border-radius: 5px;
            transition: background-color 0.3s, border-color 0.3s, color 0.3s;
        }

        .Back:hover,
        .map:hover {
            background-color: #17b890;
            border-color: darkgreen;
        }

        .Back:active,
        .map:active {
            background-color:  #082D0F;
            border-color: #004fa2;
        }

        @media only screen and (max-width: 600px) {
            form {
                max-width: 100%; /* Adjust form width to full width on smaller screens */
            }
        }
    </style>
</head>
<body>
    <h1>Pet Registration</h1>
    
   
    <!-- Registration Form -->
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <label for="petName">Pet Name:</label>
        <input type="text" id="petName" name="petName" required>

        <label for="petAge">Pet Age:</label>
        <input type="number" id="petAge" name="petAge" required>

        <label for="ownerName">Owner Name:</label>
        <input type="text" id="ownerName" name="ownerName" required>

        <input type="submit" value="Register Pet">
    </form>
    
    <!-- List of Registered Pets -->
    <h2>Our Pets</h2>
    <?php if (count($registeredPets) > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Pet Name</th>
                    <th>Pet Age</th>
                    <th>Owner Name</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($registeredPets as $index => $pet): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($pet["petName"]); ?></td>
                        <td><?php echo htmlspecialchars($pet["petAge"]); ?></td>
                        <td><?php echo htmlspecialchars($pet["ownerName"]); ?></td>
                        <td>
                            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                                <input type="hidden" name="deleteIndex" value="<?php echo $index; ?>">
                                <input type="submit" class="delete-btn" value="Delete">
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No pets registered yet.</p>
    <?php endif; ?>

    <a href="MainDashboard.php" class="Back">Return to Dashboard</a>
    <a href="map.php" class="map">Go to Map</a>
</body>
</html>
