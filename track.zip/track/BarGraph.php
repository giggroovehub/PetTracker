<!-- component -->
<div class="antialiased sans-serif  w-lg min-h-screen ">
  <link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
  <style>
    body {
      font-family: 'IBM Plex Mono', sans-serif;
    
    }

    [x-cloak] {
      display: none;
    }

    .line {
      background: repeating-linear-gradient(to bottom,
          #eee,
          #eee 1px,
          #fff 1px,
          #fff 8%);
    }

    .tick {
      background: repeating-linear-gradient(to right,
          #eee,
          #eee 1px,
          #fff 1px,
          #fff 5%);
    }
  </style>



  </script>
</div>