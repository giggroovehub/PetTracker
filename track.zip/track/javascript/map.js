var Locations = [{
    lat:32.81553000000002, 
    lon:42.190242, 
    address:'sdf',
    gval:'1',
    aType:'Oil',
    title:'abc',
    descr:'abc'             
  },
       {
    lat:-9.481553000000002, 
    lon:147.190242, 
    address:'Port Moresby',
    gval:'1',
    aType:'Oil',
    title:'Papua New Guinea',
    descr:'Papua New Guinea'            
  }
];
for (i = 0; i < Locations.length; i++) {                            
var marker = new google.maps.Marker({
map: map,
title: Locations[i].title,
position: new google.maps.LatLng(Locations[i].lat, Locations[i].lon),           
  icon: img
});



}