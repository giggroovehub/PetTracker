<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/output.css">
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/style2.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
       body {
            display: flex;
            flex-direction: row;
            background-color: white;
            margin: 0; /* Remove default margin */
            padding: 0; /* Remove default padding */
        }

        #sidebar {
            width: 20%; /* Adjust width as needed */
            height: 100vh; /* Full height */
            background-color: white; /* Sidebar background color */
            padding: 20px;
        }

        #content {
            flex-grow: 1; /* Take remaining space */
            height: 100vh; /* Full height */
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }

        #logo {
            max-width: 100%; /* Ensure image does not exceed container width */
            max-height: 100%; /* Ensure image does not exceed container height */
            width: auto; /* Allow image to adjust width automatically */
            height: auto; /* Allow image to adjust height automatically */
            object-fit: contain; /* Maintain aspect ratio */
            position: fixed; /* Fixed position relative to viewport */
            top: 10px; /* Adjust top position as needed */
            left: 500px; /* Adjust left position as needed */
        }
    </style>
    <title>Main Dashboard</title>
</head>

<body>

    <div id="sidebar">
        <?php 
            $activeMenu = 'dashboard';
            include('./sidebar.php'); 
        ?>
    </div>

    <div id="content">
        <img id="logo" src="./images/logo.png" alt="Logo">
        <?php include('./BarGraph.php') ?>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="./javascript/sessionmessage.js"></script>
    <script src="./javascript/active.js"></script>

</body>

</html>
